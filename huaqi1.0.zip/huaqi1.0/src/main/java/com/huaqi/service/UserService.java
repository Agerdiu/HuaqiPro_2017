package com.huaqi.service;

import com.huaqi.bean.User;
import com.huaqi.dao.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserMapper userMapper;

    //保存注册信息
    public void saveRegInfo(User user)
    {
        userMapper.insertSelective(user);
    }
}
