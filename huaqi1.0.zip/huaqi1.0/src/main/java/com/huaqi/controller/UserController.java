package com.huaqi.controller;

import com.huaqi.bean.Msg;
import com.huaqi.bean.User;
import com.huaqi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController {

    @Autowired
    UserService userService;
    //登录
    @RequestMapping(value="/login",method = RequestMethod.POST)
    public Msg login(User user)
    {
        return null;
    }

    //注册
    @RequestMapping(value="/register",method = RequestMethod.POST)
    @ResponseBody
    public Msg register(User user)
    {
        System.out.print(Msg.success().getMsg());
        return Msg.success();
        //userService.saveRegInfo(user);

    }
}
