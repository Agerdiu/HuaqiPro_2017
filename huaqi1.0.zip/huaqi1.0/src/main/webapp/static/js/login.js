/*********弹出登录模态框*********/
$("#login_modal_btn").click(function () {

    //弹出模态框
    $("#login_modal").modal({
        backdrop:"static"//设置模态框不会因点击退出
    });
});

/*********模态框登录按钮*********/
/*$("#login_btn").click(function () {
    
})*/

