/*********弹出注册模态框*********/
$("#register_modal_btn").click(function () {

    //弹出模态框
    $("#register_modal").modal({
        backdrop:"static"//设置模态框不会因点击退出
    });
});

/*********模态框注册按钮*********/
$("#register_btn").click(function () {
//1.提交信息给服务器保存
//2.发送ajax请求保存员工
    /*var pathName = document.location.pathname;
    var index = pathName.substr(1).indexOf("/");
    var result = pathName.substr(0,index+1);*/
    //alert($("#register_modal form").serialize());
    $.ajax({
        url:"/register",
        type:"POST",
        data:$("#register_modal form").serialize(),
        success:function (result) {
            alert($("#register_modal form").serialize());
        }
        });
});